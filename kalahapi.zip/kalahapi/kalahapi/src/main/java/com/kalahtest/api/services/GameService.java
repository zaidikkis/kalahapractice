package com.kalahtest.api.services;

import com.kalahtest.api.entities.KalahBoard;
import com.kalahtest.api.entities.dto.KalahCreateResponseDTO;
import org.springframework.stereotype.Service;

import java.util.concurrent.ThreadLocalRandom;

@Service
public class GameService {

    public static KalahBoard game;

    public KalahCreateResponseDTO createGame() {
        game = new KalahBoard(ThreadLocalRandom.current().nextLong(1, 999999999));
        KalahCreateResponseDTO createdDto = new KalahCreateResponseDTO(game.getId());
        return createdDto;
    }

    public KalahBoard makeMove(Long gameId, int pitId) throws Exception {
        if (pitId == 7 || pitId >= 14 || pitId < 1)
            throw new Exception("Invalid pit-id");
        //exception for game finished
        if (game.getGame().getPits().get(1) == 0 &&
                game.getGame().getPits().get(2) == 0 &&
                game.getGame().getPits().get(3) == 0 &&
                game.getGame().getPits().get(4) == 0 &&
                game.getGame().getPits().get(5) == 0 &&
                game.getGame().getPits().get(6) == 0) {
            throw new Exception("Player1 won");
        }
        if (game.getGame().getPits().get(8) == 0 &&
                game.getGame().getPits().get(9) == 0 &&
                game.getGame().getPits().get(10) == 0 &&
                game.getGame().getPits().get(11) == 0 &&
                game.getGame().getPits().get(12) == 0 &&
                game.getGame().getPits().get(13) == 0) {
            throw new Exception("Player2 won");
        }
        boolean player1 = false;
        boolean player2 = false;
        if (pitId >= 1 && pitId <= 6) {
            player1 = true;
        } else {
            player2 = true;
        }
        int i = pitId;
        long jumps = game.getGame().getPits().get(pitId);
        while (jumps > 0) {
            i += 1;
            if (player1 && i == 14) {
                i++;
            }
            if (player2 && i == 7) {
                i++;
            }
            game.getGame().getPits().put(i, (game.getGame().getPits().get(i) + 1));
            jumps--;
        }
        game.getGame().getPits().put(pitId, 0);
        return game;
    }

    public KalahBoard getGame(Long gameId) {
        return game;
    }
}
