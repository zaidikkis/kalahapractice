package com.kalahtest.api.entities.dto;

public class KalahCreateResponseDTO {
    private Long id;

    public KalahCreateResponseDTO(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
