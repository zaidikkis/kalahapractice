package com.kalahtest.api.entities;

import java.util.HashMap;

public class KalahBoard {
    private Long id;
    private Game game;

    public KalahBoard(Long gameId) {
        this.id = gameId;
        initiateGame();
    }

    private void initiateGame() {
        this.game = new Game();
        this.game.pits = new HashMap<>();
        for (int i = 1; i <= 14; i++) {
            if (i % 7 == 0)
                this.game.pits.put(i, 0);
            else
                this.game.pits.put(i, 4);
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public class Game {
        HashMap<Integer, Integer> pits;

        public HashMap<Integer, Integer> getPits() {
            return pits;
        }

        public void setPits(HashMap<Integer, Integer> pits) {
            this.pits = pits;
        }
    }
}
