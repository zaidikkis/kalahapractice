package com.kalahtest.api.controllers;

import com.kalahtest.api.entities.KalahBoard;
import com.kalahtest.api.entities.dto.KalahCreateResponseDTO;
import com.kalahtest.api.services.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "kalah")
public class KalahPlayerController {

    @Autowired
    private GameService gameService;

    @PostMapping
    public KalahCreateResponseDTO createGame() {
        return gameService.createGame();
    }

    @PutMapping(path = "/{game-id}/pits/{pit-id}")
    public KalahBoard makeMoveInGame(@PathVariable("game-id") Long gameId, @PathVariable("pit-id") int pitId) throws Exception {
        return gameService.makeMove(gameId, pitId);
    }

    @GetMapping(path = "/{game-id}")
    public KalahBoard getGame(@PathVariable("game-id") Long gameId) {
        System.out.println(gameId);
        return gameService.getGame(gameId);
    }
}
